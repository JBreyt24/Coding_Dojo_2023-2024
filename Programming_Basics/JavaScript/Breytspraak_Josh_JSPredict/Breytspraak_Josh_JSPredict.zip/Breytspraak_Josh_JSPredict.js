//Predict 1. "I was born in 1980"

//Predict 2. "I was born in 1980"

//Predict 3. "Summing Number!"
//           "num1 is: 10"
//           "num1 is: 20"
//           "30"
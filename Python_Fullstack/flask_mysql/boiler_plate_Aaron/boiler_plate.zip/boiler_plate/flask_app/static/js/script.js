// import swal from 'sweetalert';

// npm install --save sweetalert (to install sweetalert messages)

// function WelcomeMessage() {
//     console.log("Welcome to Counter!!!");
// }

// alert("Welcome to Counter!")